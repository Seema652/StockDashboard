import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import AddPurchaseiven from "./AddPurchaseiven";

function AddPurchaseCall() {
  return (
    <div className="App">
      <AddPurchaseiven />
    </div>
  );
}

export default AddPurchaseCall;