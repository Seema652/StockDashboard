import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Inventory from "./inventory";


function InventoryData() {
  return (
    <div className="App">
      <Inventory />
    </div>
  );
}

export default InventoryData;