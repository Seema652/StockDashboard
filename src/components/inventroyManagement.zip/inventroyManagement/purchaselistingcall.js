import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import PurchaseSearch from "./purchaselisting";


function PurchaseListingCall() {
  return (
    <div className="App">
      <PurchaseSearch />
    </div>
  );
}

export default PurchaseListingCall;