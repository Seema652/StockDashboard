import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import OrderTable from "./order";

function OrderTabels() {
  return (
    <div className="App">
      <OrderTable />
    </div>
  );
}

export default OrderTabels;