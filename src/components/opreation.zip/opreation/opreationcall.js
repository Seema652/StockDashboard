import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Operations from "./opreation";

function OpreationCall() {
  return (
    <div className="App">
      <Operations />
    </div>
  );
}

export default OpreationCall;