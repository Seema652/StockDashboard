import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Language from "./language";


function LanguageCall() {
  return (
    <div className="App">
      <Language />
    </div>
  );
}

export default LanguageCall;