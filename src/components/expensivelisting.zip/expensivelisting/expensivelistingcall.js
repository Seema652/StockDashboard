import React from "react";
import ExpensiveListing from "./expensivelisting";
const ExpensiveListCall = () => {
  return (
    <div>
<ExpensiveListing/>
    </div>
  );
};

export default ExpensiveListCall;
