import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Dashboardui from "./dashboardui";

function Dashboardpage() {
  return (
    <div className="App">
      <Dashboardui />
    </div>
  );
}

export default Dashboardpage;
