import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./datasummer";

function Datasummer() {
  return (
    <div className="App">
      <Header/>
    </div>
  );
}

export default Datasummer;