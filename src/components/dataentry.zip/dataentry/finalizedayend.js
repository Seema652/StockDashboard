import React from "react";

const FinalizeDayEnd = () => (
  <div className="bg-white p-4 shadow-sm">
    <h5>Finalize Day-End</h5>
    <p>This page allows the user to finalize the day-end process.</p>
  </div>
);

export default FinalizeDayEnd;
