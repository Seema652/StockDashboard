import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import POSApp from "./pos";

function PosInvoiceData() {
  return (
    <div className="App">
      <POSApp/>
    </div>
  );
}

export default PosInvoiceData;