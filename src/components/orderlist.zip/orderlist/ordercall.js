import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import OrderList from "./orderlist";

function OrderlistData() {
  return (
    <div className="App">
      <OrderList />
    </div>
  );
}

export default OrderlistData;