import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import MenuConfigration from "./menuconfigration";

function MenuConfigrationCall() {
  return (
    <div className="App">
      <MenuConfigration />
    </div>
  );
}

export default MenuConfigrationCall;