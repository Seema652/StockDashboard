import React from "react";
import AddItem from "./additem";

function AddItemCall() {
  return (
    <div>
      <AddItem />
    </div>
  );
}

export default AddItemCall;
