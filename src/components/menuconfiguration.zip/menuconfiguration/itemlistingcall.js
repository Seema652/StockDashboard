import React from "react";
import ItemListing from "./itemlisting";

function ItemListingCall() {
  return (
    <div>
      <ItemListing />
    </div>
  );
}

export default ItemListingCall;
