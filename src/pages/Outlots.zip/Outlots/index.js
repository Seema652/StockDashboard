import React from "react";
import Outerlots from "../../components/outlotsStatistics/Outerlots";

function Outer(){
    return(
        <div>
            <Outerlots />
        </div>
    )
}
export default Outer;